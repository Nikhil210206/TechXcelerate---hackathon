from datetime import datetime

def send_alert(event, timestamp):
    print(f"ALERT: {event} detected at {timestamp}.")
